#- =========================================================
#  Check whether required number of parameters are passed 
#  Ex. here we are checking for 5 parameters 
#  =========================================================
EXIT_STATUS=0

if [ $# -lt 4 ]
then
    echo ""
    echo "Expecting 5 parameters"
    echo ""
    echo "Usage : . GENERIC_MIGRATION_INSTALL.sh <APPS_USER_NAME>/<APPS_PASSWORD> <HOST_NAME> <PORT> <SID> "
    echo ""
	EXIT_STATUS=1
    exit $EXIT_STATUS
fi

# =================================================================================
# Export the parameter, for its availablity in child script 
# =================================================================================

p_apps_pwd=$1;  export p_apps_pwd
p_host=$2;		export p_host
p_port=$3;		export p_port
p_sid=$4;		export p_sid


# =================================================================================
# Call other scripts
# =================================================================================

#echo $p_apps $p_apps_pwd
#echo "Host:"$p_host
#echo "p_port:"$p_port
#echo "p_sid:"$p_sid

echo "Instatlling DB Component"
#. ENHC0020270_DB_sh $p_apps $p_apps_pwd $p_host $p_port $p_sid >> ENHC0020270_DB_sh.log 2>> ENHC0020270_DB_sh.err

dos2unix XXDEMO_DB.sh

. XXDEMO_DB.sh $p_apps_pwd $p_host $p_port $p_sid XXDEMODB.zip
if [ $? -eq 0 ]
then
 echo "Installtion of DB Components completed successfully"
else
  echo "Installtion of DB Components completed with some issues"
  EXIT_STATUS=1
fi
#echo "Executing ENHC0020270_AOL_sh"
#. ENHC0020270_AOL_sh $p_apps $p_apps_pwd $p_host $p_port $p_sid>> ENHC0020270_AOL_sh.log 2>> ENHC0020270_AOL_sh.err

#-
#- undefine parameters
#-

p_apps_pwd='';	export p_apps_pwd
p_host='';		export p_host
p_port='';		export p_port
p_sid='';		export p_sid


echo ""
echo "Please review generated log files for Errors/Warnings"
echo "EXIT_STATUS:$EXIT_STATUS"
exit $EXIT_STATUS
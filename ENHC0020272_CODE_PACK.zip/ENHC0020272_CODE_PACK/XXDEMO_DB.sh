#!/usr/bin/ksh 

echo "|----Component Installation Start ------|"
DB_USER_PASSWORD=$1
DB_HOST=$2
DB_PORT=$3
P_INSTANCE=$4
ZIP_FILE_NAME="$5"
EXIT_STATUS=0

echo
echo "Host :" $DB_HOST
echo ""
echo "Port :" $DB_PORT
echo " "
echo "Instance :" $P_INSTANCE
echo " "


ZIP_FILE_PATH=`pwd`

echo "Installation Directory:$ZIP_FILE_PATH"
echo "Checking file $5 in the path $ZIP_FILE_PATH"

DIR_NAME=$(echo $ZIP_FILE_NAME | cut -f 1 -d '.')
if [ -s "$ZIP_FILE_PATH/$ZIP_FILE_NAME" ]; then
  echo "File $ZIP_FILE_NAME SUCCESSFULLY checked out."
else
  echo "File $ZIP_FILE_NAME SUCCESSFULLY Not Found."
  echo "Fatal Error..."
  EXIT_STATUS=1
  exit $EXIT_STATUS
fi

# Extract the file content
 echo "Extracting Zip Files Content..."
 unzip -o $ZIP_FILE_PATH/$ZIP_FILE_NAME
 chmod 755 $ZIP_FILE_PATH/$DIR_NAME

ls -lrt $ZIP_FILE_PATH/$DIR_NAME

echo "Running Dos2unix...."
dos2unix $ZIP_FILE_PATH/$DIR_NAME/sql/xx_create_emp_table.sql

#Run files in sql plus
sqlplus -s ${DB_USER_PASSWORD} <<EOF
@$ZIP_FILE_PATH/$DIR_NAME/sql/xx_create_emp_table.sql

SELECT object_name,object_type,status,timestamp
FROM dba_objects
WHERE object_name = 'XX_DEMO_EMP_TABLE'
/

exit;
EOF

echo "****End of Installation******"
echo "EXIT_STATUS:$EXIT_STATUS"
#exit $EXIT_STATUS